from pyroquad import *
import math



class PlayerCamera:

    movespeed: float = 0.2
    cam: Camera3D
    yaw: float = 0.0
    pitch: float = -20.0
    speed: float = 0.1
    rot_speed: float = 2.0
    pitch_speed: float= 2.0
    middleMousePos: Vec2

    def __init__(self, position: Vec3 = Vec3(0,-10,0), target: Vec3 = Vec3.ZERO, aspect: float | None = None, up: Vec3 = Vec3(0,1,0), fovy: float = 0.7853, projection: Projection = Projection.Perspective, render_target: RenderTarget | None = None, viewport: tuple[int,int,int,int] | None = None, z_near: float = 0.01, z_far: float = 10_000):
        r"""run once at the start of the program after engine initialization."""
        show_mouse(False)
        set_cursor_grab(True)
        self.cam =  Camera3D(position, target, aspect, up, fovy,projection,render_target,viewport,z_near,z_far)
        self.middleMousePos =  get_mouse_position()
        
        dir_vec = target - position
        if dir_vec.x != 0 or dir_vec.y != 0 or dir_vec.z != 0:
            dir_vec = dir_vec.normalize()
            self.pitch = math.degrees(math.asin(dir_vec.y))
            self.yaw = math.degrees(math.atan2(dir_vec.x, dir_vec.z))
        else:
            self.yaw = 0.0
            self.pitch = 0.0



    def update(self):
        r"""run at the start of every frame.
        This call is a replacement for setting the 3D camera."""
        delta_time = get_delta_time()
        keys = get_keys_down()
        currentMousePos = get_mouse_position()
        
        mouseDiffX = currentMousePos.x - self.middleMousePos.x
        mouseDiffY = currentMousePos.y - self.middleMousePos.y
        self.yaw -= mouseDiffX * 0.03
        self.pitch -= mouseDiffY * 0.03
        self.middleMousePos = currentMousePos

        self.pitch = max(-89.0, min(89.0, self.pitch))

        # Forward vector
        forward = Vec3(
            math.sin(math.radians(self.yaw)) * math.cos(math.radians(self.pitch)),
            math.sin(math.radians(self.pitch)),
            math.cos(math.radians(self.yaw)) * math.cos(math.radians(self.pitch))
        ).normalize()
        
        
        # Calculate right and up vectors
        world_up = Vec3(0, 1, 0)
        right = forward.cross(world_up).normalize()
        
        FACTOR  = 100
        
        if KeyCode.W in keys:
            self.cam.position += forward * self.movespeed * delta_time * FACTOR
        if KeyCode.S in keys:
            self.cam.position -= forward * self.movespeed* delta_time*  FACTOR

        if KeyCode.A in keys:
            self.cam.position -= right * self.movespeed* delta_time* FACTOR
        if KeyCode.D in keys:
            self.cam.position += right * self.movespeed* delta_time* FACTOR
        
        zoom_factor  = 0.003
        if KeyCode.R in keys:
            self.movespeed*= (1.05** (zoom_factor/delta_time))
        if KeyCode.T in keys:
            self.movespeed*= (0.95** (zoom_factor/delta_time))
        if KeyCode.Escape in keys:
            show_mouse(True)
            set_cursor_grab(False)

        # Update camera target
        self.cam.target = self.cam.position + forward
        Camera3D.set_camera(self.cam)